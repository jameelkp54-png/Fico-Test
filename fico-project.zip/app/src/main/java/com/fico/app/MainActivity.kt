package com.fico.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Tx(val id:Long=System.currentTimeMillis(),val title:String,val amount:Double,val income:Boolean,val category:String,val date:Long=System.currentTimeMillis())

private val Blue=Color(0xFF5B5CE2)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{FicoApp(this)}}
}

class Store(private val c:Context){
 private val p=c.getSharedPreferences("fico_test",Context.MODE_PRIVATE)
 fun load():List<Tx>{
  val a=JSONArray(p.getString("tx","[]")?:"[]");val r=mutableListOf<Tx>()
  for(i in 0 until a.length()){val o=a.getJSONObject(i);r.add(Tx(o.getLong("id"),o.getString("title"),o.getDouble("amount"),o.getBoolean("income"),o.getString("category"),o.getLong("date")))}
  return r
 }
 fun save(x:List<Tx>){
  val a=JSONArray();x.forEach{t->a.put(JSONObject().apply{put("id",t.id);put("title",t.title);put("amount",t.amount);put("income",t.income);put("category",t.category);put("date",t.date)})}
  p.edit().putString("tx",a.toString()).apply()
 }
 fun budget():Double=p.getString("budget","5000")?.toDoubleOrNull()?:5000.0
 fun setBudget(v:Double){p.edit().putString("budget",v.toString()).apply()}
 fun onboarding():Boolean=p.getBoolean("onboarding",false)
 fun setOnboarding(){p.edit().putBoolean("onboarding",true).apply()}
 fun reset(){p.edit().clear().apply()}
}

@Composable fun FicoApp(ctx:Context){
 val store=remember{Store(ctx)}
 var onboard by remember{mutableStateOf(!store.onboarding())}
 var txs by remember{mutableStateOf(store.load())}
 var dark by remember{mutableStateOf(false)}
 var currency by remember{mutableStateOf("AED")}
 var budget by remember{mutableDoubleStateOf(store.budget())}
 var tab by remember{mutableIntStateOf(0)}
 var dialog by remember{mutableStateOf(false)}
 var editing by remember{mutableStateOf<Tx?>(null)}
 if(onboard){Onboarding{store.setOnboarding();onboard=false};return}
 MaterialTheme(colorScheme=if(dark)darkColorScheme(primary=Color(0xFF9A9BFF)) else lightColorScheme(primary=Blue)){
  Scaffold(bottomBar={NavigationBar{listOf("Home","Transactions","Budget","Reports","Settings").forEachIndexed{i,n->NavigationBarItem(tab==i,{tab=i},{Text(listOf("⌂","≡","◫","◔","⚙")[i],fontSize=20.sp)},{Text(n,fontSize=10.sp)})}}}){p->
   when(tab){
    0->Home(txs,currency,Modifier.padding(p)){dialog=true;editing=null}
    1->Transactions(txs,currency,Modifier.padding(p),{editing=it;dialog=true},{id->txs=txs.filter{it.id!=id};store.save(txs)})
    2->Budget(txs,budget,currency,Modifier.padding(p)){v->budget=v;store.setBudget(v)}
    3->Reports(txs,currency,Modifier.padding(p))
    4->Settings(dark,currency,Modifier.padding(p),{dark=!dark},{currency=if(currency=="AED")"USD" else "AED"},txs,ctx,{store.reset();txs=emptyList();budget=5000.0})
   }
  }
  if(dialog) TxDialog(currency,editing,{dialog=false}){t->
   txs=if(editing==null)listOf(t)+txs else txs.map{if(it.id==editing!!.id)t else it}
   store.save(txs);dialog=false
  }
 }
}

@Composable fun Onboarding(done:()->Unit){
 Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
  Surface(color=Blue,shape=RoundedCornerShape(30.dp),modifier=Modifier.size(110.dp)){Box(contentAlignment=Alignment.Center){Text("F",color=Color.White,fontSize=58.sp,fontWeight=FontWeight.Bold)}}
  Spacer(Modifier.height(30.dp));Text("Welcome to Fico",fontSize=30.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));Text("Track income, expenses and budgets simply.",color=Color.Gray);Spacer(Modifier.height(30.dp));Button(done,Modifier.fillMaxWidth().height(54.dp)){Text("Start")}}
}

@Composable fun Home(t:List<Tx>,c:String,m:Modifier,add:()->Unit){
 val inc=t.filter{it.income}.sumOf{it.amount};val exp=t.filter{!it.income}.sumOf{it.amount}
 Column(m.fillMaxSize().padding(20.dp)){Spacer(Modifier.height(15.dp));Text("Good morning 👋",color=Color.Gray);Text("Fico",fontSize=32.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(15.dp))
 Card(colors=CardDefaults.cardColors(Blue),shape=RoundedCornerShape(26.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp)){Text("Total Balance",color=Color.White.copy(.7f));Text("$c %.2f".format(inc-exp),color=Color.White,fontSize=30.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween){Text("Income\n$c %.2f".format(inc),color=Color.White);Text("Expenses\n$c %.2f".format(exp),color=Color.White)}}}
 Spacer(Modifier.height(18.dp));Text("Recent transactions",fontSize=20.sp,fontWeight=FontWeight.Bold);t.take(5).forEach{TxRow(it,c)};Spacer(Modifier.weight(1f));Text("Advertisement • test placeholder",fontSize=11.sp,color=Color.Gray);Spacer(Modifier.height(6.dp));Button(add,Modifier.fillMaxWidth().height(54.dp)){Text("+ Add Transaction")}}
}

@Composable fun Transactions(t:List<Tx>,c:String,m:Modifier,edit:(Tx)->Unit,delete:(Long)->Unit){
 var q by remember{mutableStateOf("")};var incomeOnly by remember{mutableStateOf(false)};var expenseOnly by remember{mutableStateOf(false)}
 val shown=t.filter{(it.title.contains(q,true)||it.category.contains(q,true))&&(!incomeOnly||it.income)&&(!expenseOnly||!it.income)}
 Column(m.fillMaxSize().padding(20.dp)){Text("Transactions",fontSize=30.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Search")});Row{FilterChip(incomeOnly,{incomeOnly=!incomeOnly},{Text("Income")});Spacer(Modifier.width(6.dp));FilterChip(expenseOnly,{expenseOnly=!expenseOnly},{Text("Expense")})};LazyColumn{items(shown,key={it.id}){t->SwipeRow(t,c,{edit(t)},{delete(t.id)})}}}
}

@Composable fun SwipeRow(t:Tx,c:String,edit:()->Unit,delete:()->Unit){
 Card(Modifier.fillMaxWidth().padding(vertical=3.dp),shape=RoundedCornerShape(15.dp)){Row(Modifier.padding(13.dp).fillMaxWidth(),Arrangement.SpaceBetween,Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(t.title,fontWeight=FontWeight.SemiBold);Text("${t.category} • "+SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(Date(t.date)),color=Color.Gray,fontSize=12.sp)};Text("${if(t.income)"+" else "-"} $c %.2f".format(t.amount),fontWeight=FontWeight.Bold);Spacer(Modifier.width(5.dp));TextButton(edit){Text("Edit")};TextButton(delete){Text("Delete")}}}
}

@Composable fun TxRow(t:Tx,c:String){Card(Modifier.fillMaxWidth().padding(vertical=3.dp),shape=RoundedCornerShape(15.dp)){Row(Modifier.padding(13.dp).fillMaxWidth(),Arrangement.SpaceBetween){Column{Text(t.title,fontWeight=FontWeight.SemiBold);Text(t.category,color=Color.Gray,fontSize=12.sp)};Text("${if(t.income)"+" else "-"} $c %.2f".format(t.amount),fontWeight=FontWeight.Bold)}}}

@Composable fun Budget(t:List<Tx>,b:Double,c:String,m:Modifier,set:(Double)->Unit){
 var value by remember(b){mutableStateOf(if(b==0.0)"" else b.toString())};val e=t.filter{!it.income}.sumOf{it.amount};val pct=(e/b.coerceAtLeast(1.0)).coerceAtMost(1.0).toFloat()
 Column(m.fillMaxSize().padding(20.dp)){Text("Budget",fontSize=30.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp));OutlinedTextField(value,{value=it},label={Text("Monthly budget ($c)")});Spacer(Modifier.height(8.dp));Button({value.toDoubleOrNull()?.let(set)}){Text("Save Budget")};Spacer(Modifier.height(20.dp));Text("$c %.2f spent of $c %.2f".format(e,b),fontWeight=FontWeight.Bold);LinearProgressIndicator(pct,Modifier.fillMaxWidth());Text(if(e>b)"Over budget by $c %.2f".format(e-b) else "$c %.2f remaining".format(b-e),color=Color.Gray)}}

@Composable fun Reports(t:List<Tx>,c:String,m:Modifier){
 val exp=t.filter{!it.income};val total=exp.sumOf{it.amount};val groups=exp.groupBy{it.category}.mapValues{it.value.sumOf{v->v.amount}}.toList().sortedByDescending{it.second}
 Column(m.fillMaxSize().padding(20.dp)){Text("Reports",fontSize=30.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(15.dp));Text("Total expenses: $c %.2f".format(total),fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));groups.forEach{(cat,v)->val pct=if(total==0.0)0f else (v/total).toFloat();Text(cat,fontWeight=FontWeight.SemiBold);LinearProgressIndicator(pct,Modifier.fillMaxWidth());Text("$c %.2f  •  %.1f%%".format(v,pct*100),color=Color.Gray,fontSize=12.sp);Spacer(Modifier.height(8.dp))}}
}

@Composable fun Settings(dark:Boolean,c:String,m:Modifier,toggle:()->Unit,currency:()->Unit,t:List<Tx>,ctx:Context,reset:()->Unit){
 var confirm by remember{mutableStateOf(false)}
 Column(m.fillMaxSize().padding(20.dp)){Text("Settings",fontSize=30.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(18.dp));Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween){Text("Dark mode");Switch(dark,{toggle()})};Divider();Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween){Text("Currency");Button(currency){Text(c)}};Spacer(Modifier.height(18.dp));Button({shareCsv(t,ctx)}){Text("Export / Share CSV")};Spacer(Modifier.height(10.dp));OutlinedButton({confirm=true}){Text("Reset all data")};Spacer(Modifier.height(25.dp));Text("Fico Test 2.1",color=Color.Gray,fontSize=12.sp);Text("Local test build • no production ads",color=Color.Gray,fontSize=12.sp)}
 if(confirm)AlertDialog(onDismissRequest={confirm=false},title={Text("Reset all data?")},text={Text("This permanently clears local transactions and settings.")},confirmButton={Button({reset();confirm=false}){Text("Reset")}},dismissButton={TextButton({confirm=false}){Text("Cancel")}})}
}

private fun shareCsv(t:List<Tx>,ctx:Context){
 val csv=buildString{append("Title,Amount,Type,Category,Date\n");t.forEach{x->append("\"${x.title.replace("\"","\"\"")}\",${x.amount},${if(x.income)"Income" else "Expense"},\"${x.category.replace("\"","\"\"")}\",${SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(x.date))}\n")}}
 ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/csv";putExtra(Intent.EXTRA_TEXT,csv);putExtra(Intent.EXTRA_SUBJECT,"Fico transactions")},"Share Fico CSV"))
}

@Composable fun TxDialog(c:String,editing:Tx?,close:()->Unit,save:(Tx)->Unit){
 var title by remember(editing){mutableStateOf(editing?.title?:"")};var amount by remember(editing){mutableStateOf(editing?.amount?.toString()?:"")};var cat by remember(editing){mutableStateOf(editing?.category?:"Other")};var inc by remember(editing){mutableStateOf(editing?.income?:false)}
 AlertDialog(onDismissRequest=close,title={Text(if(editing==null)"Add Transaction" else "Edit Transaction")},text={Column{Row(Modifier.fillMaxWidth(),Arrangement.SpaceEvenly){FilterChip(inc,{inc=true},{Text("Income")});FilterChip(!inc,{inc=false},{Text("Expense")})};OutlinedTextField(amount,{amount=it},label={Text("Amount ($c)")});OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(cat,{cat=it},label={Text("Category")})}},confirmButton={Button({amount.toDoubleOrNull()?.takeIf{it>0}?.let{save(Tx(editing?.id?:System.currentTimeMillis(),title.ifBlank{"Transaction"},it,inc,cat.ifBlank{"Other"},editing?.date?:System.currentTimeMillis()))}}){Text("Save")}},dismissButton={TextButton(close){Text("Cancel")}})
}